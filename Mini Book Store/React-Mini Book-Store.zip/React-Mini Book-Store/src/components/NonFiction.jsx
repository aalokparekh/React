export default function NonFiction() {
  return (
    <div>
      <h1>Non-Fiction Book</h1>

      <div className="books-container">
        {/* Display all Non-Fiction books here */}
      </div>
    </div>
  );
}
