function App() {
  return (
    <div>
      <h1>Mini Book Store</h1>

      <button data-testid="toggle-btn"></button>

      <div data-testid="conditional-container">
        {/* Render either Fiction or NonFiction Based on the Condition */}
      </div>
    </div>
  );
}

export default App;
